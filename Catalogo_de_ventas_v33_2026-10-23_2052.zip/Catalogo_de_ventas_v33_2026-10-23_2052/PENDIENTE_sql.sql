-- Pegar en Supabase → SQL Editor → Run (cambios chicos que quedaron pendientes)

-- 1) Que una tienda vea su plan aunque el plan esté oculto/desactivado
alter policy plans_read on public.plans
  using ((is_active and is_public) or private.is_platform_admin()
         or exists (select 1 from public.stores s where s.plan_id = plans.id and (s.status = 'active' or private.is_store_member(s.id))));

-- 2) Subir el límite de cada foto a 5 MB
update storage.buckets set file_size_limit = 5242880 where id = 'store-media';

-- 3) Administradores extra por tienda (solo el administrador general)
create or replace function public.admin_add_member(p_store uuid, p_email text) returns text
language plpgsql security definer set search_path = '' as $$
declare uid uuid;
begin
  if not private.is_platform_admin() then raise exception 'no autorizado'; end if;
  select id into uid from auth.users where lower(email) = lower(trim(p_email)) limit 1;
  if uid is null then return 'no_user'; end if;
  insert into public.store_members(store_id,user_id,role) values (p_store,uid,'admin') on conflict do nothing;
  return 'ok';
end $$;
create or replace function public.admin_remove_member(p_store uuid, p_user uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_platform_admin() then raise exception 'no autorizado'; end if;
  delete from public.store_members where store_id = p_store and user_id = p_user and role <> 'owner';
end $$;
create or replace function public.admin_list_members(p_store uuid) returns table(user_id uuid, email text, role text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if not private.is_platform_admin() then raise exception 'no autorizado'; end if;
  return query select m.user_id, u.email::text, m.role from public.store_members m join auth.users u on u.id = m.user_id where m.store_id = p_store;
end $$;
revoke execute on function public.admin_add_member(uuid,text), public.admin_remove_member(uuid,uuid), public.admin_list_members(uuid) from public, anon;
grant execute on function public.admin_add_member(uuid,text), public.admin_remove_member(uuid,uuid), public.admin_list_members(uuid) to authenticated;

-- 4) Hacerte administrador general (hacelo DESPUÉS de entrar una vez con tu Google en la plataforma)
-- insert into public.platform_admins(user_id, email)
--   select id, email from auth.users where email = 'klavdivsjac@gmail.com';
