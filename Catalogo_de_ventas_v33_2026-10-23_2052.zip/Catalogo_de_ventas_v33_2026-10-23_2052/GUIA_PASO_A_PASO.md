# Cómo actualizar la plataforma a la v33 (sin tocar la tienda de Cami)

IMPORTANTE: **no reemplaces index.html** (es la tienda de Cami con Firebase).

1. En el celular, renombrá Catalogo_de_ventas_v33_2026-10-23_2052.html a **plataforma.html** (todo minúscula).
2. Abrí https://github.com/klavdivsjac-arch/Tienda/upload/main
3. Subí **plataforma.html** (reemplaza al anterior) y **preview.png** (imagen que sale al compartir el link; solo la primera vez).
4. Commit changes y esperá 1-2 minutos.
5. Probá: https://klavdivsjac-arch.github.io/Tienda/plataforma.html?v=33 — abajo del todo debe decir "Versión v33".

Nota: WhatsApp guarda la vista previa de los links ya compartidos; para links nuevos se ve la imagen nueva.
