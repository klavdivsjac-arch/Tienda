# Catálogo de ventas — v33 (plataforma multi-tienda sobre Supabase)

## Qué es
Una sola página (HTML) que sirve a cientos de tiendas independientes. Cada tienda se abre con `?t=nombre-del-link`
(ej: `.../Tienda/plataforma.html?t=cami-helados`). Sin ese parámetro se ve la portada de la plataforma.

## Pantallas de la plataforma (sin ?t=)
- Portada con planes y botón "Crear mi catálogo gratis" (login con Google → nombre, link, aceptar términos).
- `#/mis-tiendas`: tiendas del usuario con links para ver/administrar/copiar.
- `#/super` (solo administrador general): Tiendas (buscar, entrar a cualquiera, cambiar plan, registrar pago, prueba, cortesía, ajustes propios JSON, administradores extra, pausar/bloquear), Planes (crear/duplicar/editar/eliminar: precio, descuento anual, prueba, límites y funciones), Pagos, Denuncias, Ajustes (nombre, frase, WhatsApp de contacto, gracia, términos).
- `#/terminos`, `#/privacidad` (texto básico editable; conviene revisión legal).

## Dentro de cada tienda
Todo lo de v29 (catálogo, carrito, pedidos, servicios/publicidad, galerías, banners, bienvenida, registro opcional/obligatorio, sabores, cupones, zonas, clientes, panel) + 
- `#/admin/plan` (Mi plan: plan actual, vencimiento, límites, pedir cambio por WhatsApp).
- Funciones bloqueadas por plan muestran 🔒 y una pantalla "Ver planes".
- Marca "Hecho con…" + "Denunciar" en el pie si el plan no incluye "sin marca".
- Fotos: se suben a Supabase Storage (ya no base64 dentro de la base).
- Pedidos en vivo para el administrador (tiempo real + refresco cada 20 s); el cliente sigue su pedido por link secreto.

## Novedades v33
- Al tocar "Compartir" en una tienda se comparte la foto de portada (o el logo) junto con el link: en WhatsApp sale la imagen y el texto con el link.
- Vista previa genérica al pegar el link en WhatsApp/Facebook (título "Catálogo online" e imagen preview.png). Para que cada tienda muestre SU propia imagen al pegar el link hace falta un servidor intermedio (p. ej. Cloudflare con dominio propio): queda como mejora futura.

## Novedades v32
- Menú de la tienda abajo (barra inferior): Inicio, Carrito (con contador), Cuenta, Administrar (solo admin) e idioma. Más cómodo con una mano.
- La versión de la app se muestra en el pie de la tienda, en la plataforma y en el panel de administración.

## Novedades v31
- El administrador/dueño no puede hacer pedidos en su propia tienda (el carrito muestra un aviso; para probar, cerrar sesión o usar otro celular).
- Instalable como app: manifest con el nombre completo de la tienda, icono PNG generado desde su logo (o emoji), nombre para iPhone, sw.js opcional y botón "📲 Instalar app" en el pie.

## Planes de ejemplo (editables)
Semilla gratis (10 productos) · Básico ₲30.000 · Pro ₲70.000 · Negocio ₲150.000. Los precios/límites son provisorios.

## Pendiente / siguientes pasos
1. Ejecutar PENDIENTE_sql.sql (plan visible, bucket 5 MB, administradores extra) y hacerte administrador general.
2. Migrar Cami Helados de Firebase (script, necesita export).
3. Dominio propio (Cloudflare), links más cortos (`dominio/nombre`), cobro automático, anti-abuso extra (límite de pedidos por IP), alternativa a Google.
4. Revisión legal de términos/privacidad (Paraguay).
