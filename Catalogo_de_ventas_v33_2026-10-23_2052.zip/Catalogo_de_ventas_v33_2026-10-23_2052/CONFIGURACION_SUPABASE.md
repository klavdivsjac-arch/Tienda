# Configuración de Supabase (plataforma multi-tienda)

- Proyecto: `catalogo` · ref `ocwrpyumrquxiquvgnbl` · región São Paulo · cuenta catalogodeventaspersonalizado@gmail.com
- URL: https://ocwrpyumrquxiquvgnbl.supabase.co (la "anon key" está dentro del HTML: es pública por diseño; la seguridad la dan las reglas RLS).
- Acceso con Google: Authentication → Providers → Google (Client ID/Secret de Google Cloud, proyecto `catalogo-512402`, cliente "catalogo web").
  - Redirect de Google: https://ocwrpyumrquxiquvgnbl.supabase.co/auth/v1/callback
  - Supabase → URL Configuration: Site URL y Redirect URLs `https://klavdivsjac-arch.github.io/Tienda/` y `.../Tienda/**`
- Google Cloud → Público: la app debe estar **Publicada** (si no, solo entran usuarios de prueba).

## Tablas (esquema public)
| Tabla | Para qué |
|---|---|
| stores | cada tienda: slug (link), name, owner_id, owner_email, status (active/paused/banned), plan_id, paid_until, overrides (límites/funciones propias), notes |
| plans | planes editables: precio mensual, % descuento anual, días de prueba, limits{max_products,max_photos,max_banners,extra_admins}, features{banner,welcome,gallery_collage,...}, activo/público/orden |
| store_members | quién administra cada tienda (owner/admin) |
| store_docs | **datos de cada tienda** como registros clave→JSON: config, products, banners, banner_*, pimg_*, order_*, cust_*, views, clicks (las fotos van a Storage; acá solo URLs) |
| platform_admins | administradores generales (ven y editan todo) |
| platform_settings | brand (nombre, frase, WhatsApp de contacto, días de gracia) y terms |
| payments, reports | pagos registrados a mano y denuncias |
| reserved_slugs | nombres de link no permitidos (admin, api, www…) |
| store_stats | visitas/consultas por día (rpc track_event) |
| products, product_images, banners, orders, order_items, customers, coupons, delivery_zones | tablas relacionales creadas para uso futuro (hoy la app usa store_docs) |

Storage: bucket público `store-media`, carpeta por tienda `<store_id>/archivo`; solo miembros de esa tienda escriben.

## Seguridad (RLS) — probada con usuarios de prueba
- Visitante: ve solo tiendas activas y sus datos públicos (config, products, banners, fotos). Puede **crear** pedidos y denuncias; no puede leer pedidos, clientes ni pagos.
- Dueño/admin de tienda: lee y escribe solo lo suyo. No puede cambiar su plan, estado, vencimiento, overrides ni link.
- Cliente registrado: lee/crea/edita solo su ficha `cust_<su id>`.
- Administrador general: ve y edita todo; registra pagos con la función `admin_register_payment`.
- Límites de plan: trigger que corta el producto N+1 (`max_products`); fotos por producto se limitan en la app.
- Alta de tienda: trigger fuerza plan gratis (semilla), estado activo, máximo 3 tiendas por cuenta, bloquea nombres reservados.
- Funciones públicas a propósito: get_order_status, get_order_doc, track_event, track_doc, slug_available.

## Vencimiento de planes
Si `paid_until` + días de gracia pasó y el plan es pago, la app usa el plan gratis (semilla). No se borra nada. Cortesía = vencimiento 2099.
