# Cómo actualizar la plataforma a la v32 (sin tocar la tienda de Cami)

IMPORTANTE: **no reemplaces index.html** (es la tienda de Cami con Firebase).

1. Abrí https://github.com/klavdivsjac-arch/Tienda/upload/main
2. Subí **Catalogo_de_ventas_v32_2026-10-23_1953.html renombrado a plataforma.html** (reemplaza al anterior).
3. Subí también **sw.js** (tal cual, sin renombrar; hace que el navegador ofrezca "Instalar app").
4. Commit changes y esperá 1-2 minutos.
5. Abrí https://klavdivsjac-arch.github.io/Tienda/plataforma.html (si ves lo viejo, cerrá y volvé a abrir la página).

Novedades v32: menú abajo y versión visible en la app. Antes (v31): el dueño/administrador no puede comprar en su propia tienda; la app se instala con el nombre completo de la tienda y su logo como icono (Android: "Instalar app"; iPhone: Compartir → Agregar a pantalla de inicio); botón "📲 Instalar app" en el pie de cada tienda.
